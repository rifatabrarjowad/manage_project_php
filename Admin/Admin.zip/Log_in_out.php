<html class="bg-black">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <title>সততা ক্যাবল নেটওয়ার্ক এন্ড পাপিয়া ওয়াইফাই | Log in</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css">

</head>

<body class="bg-black" data-new-gr-c-s-check-loaded="14.981.0">

    <form action="log.php" method="post">

        <div class="form-box" id="login-box">
            <div class="header bg-blue">Sign In</div>

            <div class="body bg-gray" align="center">
                <div class="form-group" style="border: #066 1px solid;">
                    <input type="text" name="username" class="form-control" required placeholder="Username">
                </div>
                <div class="form-group" style="border: #066 1px solid;">
                    <input type="password" name="password" class="form-control" required placeholder="Password">
                </div>

                <div class="form-group" style="color: red;">
                </div>
                <div class="form-group" style="color: red;">
                </div>
            </div>
            <div class="footer">
                <input type="submit" class="btn bg-blue btn-block" name="submit" value="Log in" />
            </div>

        </div>

    </form>


</body>

</html>